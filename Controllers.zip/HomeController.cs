﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using U21493198_HW03.Models;

namespace U21493198_HW03.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(FileModel file)
        {
            string filename = "";

            //checks file type and puts it in the correct folder based on the file type
            if (filename.Contains("jpeg")  || filename.Contains("png") || filename.Contains("eps") || filename.Contains("psd"))
            {
                string path = Server.MapPath("~/App_Data/Media/Images");
                filename = Path.GetFileName(file.myfile.FileName);
                string fullPath = Path.Combine(path, filename);
                file.myfile.SaveAs(fullPath);
            }  
            else if(filename.Contains("mp4") || filename.Contains("xspf") || filename.Contains("mov") || filename.Contains("flv") || filename.Contains("avi"))
            {
                string path = Server.MapPath("~/App_Data/Media/Videos");
                filename = Path.GetFileName(file.myfile.FileName);
                string fullPath = Path.Combine(path, filename);
                file.myfile.SaveAs(fullPath);
            }
            else
            {
                string path = Server.MapPath("~/App_Data/Media/Documents");
                filename = Path.GetFileName(file.myfile.FileName);
                string fullPath = Path.Combine(path, filename);
                file.myfile.SaveAs(fullPath);
            }
             //saves selected radiobutton info
           /* string pth = Server.MapPath("~/App_Data/Radiobutton");
            string flename = Path.GetFileName(file.upload.FileName);
            string fllPath = Path.Combine(pth, flename);
            file.upload.SaveAs(fllPath);*/
            return View();
        }


        
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

       
    }
}