﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace U21493198_HW03.Models
{
    public class FileModel
    {
        public HttpPostedFileBase upload { get; set; }
        public HttpPostedFileBase myfile { get; set; }

       
        public string FileName { get; set; }
        
       
    }
}