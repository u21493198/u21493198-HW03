﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using U21493198_HW03.Models;

namespace U21493198_HW03.Controllers
{
    public class VideoController : Controller
    {
        // GET: Video
        public ActionResult IndexVideo()
        {
            string[] pathsoffiles = Directory.GetFiles(Server.MapPath("~/App_Data/Media/Videos/"));
            List<FileModel> file = new List<FileModel>();
            foreach (string pathoffile in pathsoffiles)
            {
                file.Add(new FileModel { FileName = Path.GetFileName(pathoffile) });
            }
            return View(file);

        }

        public FileResult DownloadFile(string fileName)
        {
            string filepath = Server.MapPath("~/ App_Data / Media / Documents") + fileName;
            byte[] bytes = System.IO.File.ReadAllBytes(filepath);
            return File(bytes, "application/octet-stream");
        }

        public ActionResult DeleteFile(string[] filename)
        {
            foreach (var fullname in filename)
            {
                var filenames = Path.GetFileName(fullname);
                var physicalpath = Path.Combine(Server.MapPath("~/ App_Data / Media / Documents"), filenames);
                if (System.IO.File.Exists(physicalpath))
                {
                    System.IO.File.Delete(physicalpath);
                }
            }

            return Content("");
        }

    }
}